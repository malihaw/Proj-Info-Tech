<div id="footer-border"></div>

<div class="footerMsg">
		<div id=signature>
        	<h6>Dinousaursninja</h6>
            <h6>more info here</h6>
        </div>
</div>

<!--This for some reason has to go here so materialize works (line 7 - 16)-->
<!-- materializecss lib -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>