<meta charset="utf-8">
<meta name="generator" content="AlterVista - Editor HTML"/>

<!--This is my traditional head tag-->
<!--Import the stylesheet and css from Materialize -->
<!-- Materialize -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

<!-- Font-Awesome -->
<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
<!-- JQuery runs functions-->
<script src="https://code.jquery.com/jquery-2.1.1.min.js"></script>


<!-- Js Loader runs magic loader as part of header -->
<script src="MagicLoader.js?5"></script>

<!--SSTYLE SHEET -- is giving me problems -->
<link href="Style_Sheet.css?38" rel="stylesheet" />

<!-- check css page now
CSS Style for store layout(merch, row, col, card)
<style>
.brand-logo{

}
#merch .col{
padding: 1em;
/*border: 5px solid green;**/         
}
#row .row{
padding: 5em;
border: 10px solid yellow;
}
#footer-border{
background-image: url("http://practicewebpage.altervista.org/Images/Footer_image.svg");
background-position: bottom;
background-size: contain;
background-repeat: repeat-x;
width: 100%;
height: 100px;
background-color: white !important;
}
#merch .card-image.waves-effect{
overflow: initial;
}
#merch .card-content{
padding-top: 34px;
}
</style>

<!--This creates a side nav collapsible and functional when collapse 
<script>
$(document).ready(function() {
$('.sidenav').sidenav({draggable: true});

// Site under construction message
M.toast({html: "Site under construction", classes: "rounded"});
});
</script>
-->


