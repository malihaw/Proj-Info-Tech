<!DOCTYPE html>
<html>
<head>

<?php
	include_once('Header.php');    
?>


<title>Esc-19</title>
</head>

<body>  
<?php
	include_once('NavBar_Main.php');	
?>     
     <div class="aboutMain">
     
     <!--  <div class="titleContainer">
             <div class="parallax-container">
               <div class="parallax"><img src="https://th.bing.com/th/id/OIP.kX29rAD97PIbk1Pw6-NdOAHaHa?pid=ImgDet&rs=1"></div>
             </div>       
             <h1> Escape Covid-19 </h1>
       </div>
       -->

    <div class="parallax-container">
      <div class="parallax">
      <img src="https://images.squarespace-cdn.com/content/v1/5a5d344cb7411c8b282df032/1516763218451-938NCOE77SQ9ZOCMKU9X/ke17ZwdGBToddI8pDm48kLkXF2pIyv_F2eUT9F60jBl7gQa3H78H3Y0txjaiv_0fDoOvxcdMmMKkDsyUqMSsMWxHk725yiiHCCLfrh8O1z4YTzHvnKhyp6Da-NYroOW3ZGjoBKy3azqku80C789l0iyqMbMesKd95J-X4EagrgU9L3Sa3U8cogeb0tjXbfawd0urKshkc5MgdBeJmALQKw/pietro-de-grandi-329892.jpg"></div>
    </div>
    
    <div class="section white">
      <div class="row container">
        <h2 class="header">About Us</h2>
        <p class="grey-text text-darken-3 lighten-3">
            Idea behind the site here
            	ESC-19 was created with the idea of helping the public <br>
                keep mentally and physically active admist the pandemic.<br>
                Prodoviding an alternative to cabin fever while maintaining <br>
                safety protocols in place. <br>
      </div>      
    </div>
    
      <div class="parallax-container">
      <div class="parallax"><img src="https://latenightparents.com/wp-content/uploads/2020/07/outdoors.jpeg"></div>     	 
     </div>
    
         <div class="row container">    	 
         <h2 class="header">Our Misison</h2>
         <p class="grey-text text-darken-3 lighten-3">
         	Our Goal is to provide a provide a the space for a community who<br>
            wishes to ___. Providing free outdoor crash course with the basics for a <br>
            variarity of activities such as hiking, running, biking. A community <br>
            to socialize with and a easy access store to find the equipments you might <br>
            need to pick up a new hobbie. <br>
            <p>
            
         <h2 class="header">Purpose of this project</h2>
         <p class="grey-text text-darken-3 lighten-3">
            Demonstrate a series of vulnerabilites or attacks directed at <br>
            E-commerce sites and how to protect agaisnt them.<br>
            </p>
        </div>
    
       
    <!--
    <div id="aboutUs">
       		<h4>About Us</h4>
            <p> Idea behind the site here</p>
            <p>
            	ESC-19 was created with the idea of helping the public <br>
                keep mentally and physically active admist the pandemic.<br>
                Prodoviding an alternative to cabin fever while maintaining <br>
                safety protocols in place. <br>
             </p>
       </div>       
       <div #id="mission">
       		<h4>Our Misison</h4>
            <p> Our Goal is to provide a provide a the space for a community who<br>
            wishes to ___. Providing free outdoor crash course with the basics for a <br>
            variarity of activities such as hiking, running, biking. A community <br>
            to socialize with and a easy access store to find the equipments you might <br>
            need to pick up a new hobbie. <br>
            <p>
       </div>       
       <div id="projectPurpose">
       		<h4>Purpose of this Project</h4>
            <p>
            Demonstrate a series of vulnerabilites or attacks directed at <br>
            E-commerce sites and how to protect agaisnt them.<br>
            </p>
            <br><br><br><br>
       </div> -->
       
     </div>        
   <footer>
   		<?php include_once('Footer.php'); ?>
   </footer>
        
        
</body>
</html>
